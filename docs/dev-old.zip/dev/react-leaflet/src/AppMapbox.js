import React, { Component } from 'react';
import MapGL, { Marker, Popup, NavigationControl } from 'react-map-gl';
const TOKEN =
  'pk.eyJ1IjoiZ3JnZHByIiwiYSI6ImNqbm02enc0bTFuNGIza28zdmRjMHNsN2oifQ.ltm3vhFfEq_-z0DXSfGDKQ';

const navStyle = {
  position: 'absolute',
  top: 0,
  left: 0,
  padding: '10px'
};
export default class Map extends Component {
  constructor(props) {
    super(props);
    this.state = {
      viewport: {
        latitude: 48.859,
        longitude: 2.321,
        zoom: 10,
        bearing: 0,
        pitch: 0,
        width: 800,
        height: 600
      }
    };
  }
  render() {
    const { viewport } = this.state;
    return (
      <MapGL
        {...viewport}
        onViewportChange={viewport => this.setState({ viewport })}
        mapStyle="mapbox://styles/mapbox/light-v9"
        mapboxApiAccessToken={TOKEN}
      >
        <div className="nav" style={navStyle}>
          <NavigationControl />
        </div>
      </MapGL>
    );
  }
}
