import React from 'react';
import {
  GoogleApiWrapper,
  InfoWindow,
  Map,
  Marker,
  Polygon,
  Polyline,
  Circle
} from 'google-maps-react';

const coords = { lat: -21.805149, lng: -49.0921657 };


class GoogleMapsContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showingInfoWindow: false,
      activeMarker: {},
      selectedPlace: {}
    };
    // binding this to event-handler functions
    this.onMarkerClick = this.onMarkerClick.bind(this);
    this.onMapClick = this.onMapClick.bind(this);
  }
  onMarkerClick = (props, marker, e) => {
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });
  };
  onMapClick = props => {
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };
  render() {
    const style = {
      width: '100vw',
      height: '100vh',
      marginLeft: 'auto',
      marginRight: 'auto'
    };
    var triangleCoords = [
      { lat: 48.89, lng: 2.32 },
      { lat: 48.85, lng: 2.4 },
      { lat: 48.81, lng: 2.34 }
    ];
    var triangle2Coords = [
      { lat: 48.861, lng: 2.35 },
      { lat: 48.8, lng: 2.3 },
      { lat: 48.872, lng: 2.33 },
      { lat: 48.881, lng: 2.321 },
      { lat: 48.865, lng: 2.33 }
    ];
    const coords = { lat: 48.865, lng: 2.321 };

    return (
      <Map
        google={this.props.google}
        onClick={this.onMapClick}
        zoom={12}
        initialCenter={{ lat: 48.859, lng: 2.321 }}
        style={style}
        styles={[
          {
            featureType: 'all',
            elementType: 'labels.text.fill',
            stylers: [
              { saturation: 36 },
              { color: '#333333' },
              { lightness: 40 }
            ]
          },
          {
            featureType: 'all',
            elementType: 'labels.text.stroke',
            stylers: [
              { visibility: 'on' },
              { color: '#ffffff' },
              { lightness: 16 }
            ]
          },
          {
            featureType: 'all',
            elementType: 'labels.icon',
            stylers: [{ visibility: 'off' }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.fill',
            stylers: [{ color: '#fefefe' }, { lightness: 20 }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{ color: '#fefefe' }, { lightness: 17 }, { weight: 1.2 }]
          },
          {
            featureType: 'landscape',
            elementType: 'geometry',
            stylers: [{ color: '#dadada' }, { lightness: 20 }]
          },
          {
            featureType: 'poi',
            elementType: 'all',
            stylers: [{ visibility: 'off' }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{ color: '#f5f5f5' }, { lightness: 21 }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry',
            stylers: [{ color: '#dedede' }, { lightness: 21 }]
          },
          {
            featureType: 'road',
            elementType: 'all',
            stylers: [{ visibility: 'on' }]
          },
          {
            featureType: 'road',
            elementType: 'labels',
            stylers: [{ visibility: 'on' }]
          },
          {
            featureType: 'road',
            elementType: 'labels.icon',
            stylers: [{ visibility: 'off' }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.fill',
            stylers: [{ color: '#ffffff' }, { lightness: 17 }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{ color: '#ffffff' }, { lightness: 29 }, { weight: 0.2 }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{ color: '#ffffff' }, { lightness: 18 }]
          },
          {
            featureType: 'road.local',
            elementType: 'geometry',
            stylers: [{ color: '#ffffff' }, { lightness: 16 }]
          },
          {
            featureType: 'transit',
            elementType: 'all',
            stylers: [{ visibility: 'on' }]
          },
          {
            featureType: 'transit',
            elementType: 'geometry',
            stylers: [{ color: '#f2f2f2' }, { lightness: 19 }]
          },
          {
            featureType: 'transit.station',
            elementType: 'all',
            stylers: [{ visibility: 'simplified' }]
          },
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{ color: '#a8a8a8' }, { lightness: 17 }]
          }
        ]}
      >
        <Polygon
          paths={triangleCoords}
          strokeColor="green"
          strokeOpacity={0}
          strokeWeight={2}
          fillColor="yellow"
          fillOpacity={0.75}
          name={'1'}
        />

        <Polygon
          paths={triangle2Coords}
          strokeColor="black"
          strokeOpacity={1}
          strokeWeight={4}
          fillColor="red"
          fillOpacity={0}
          name={'2'}
        />

        <Marker
          onClick={this.onMarkerClick}
          title={'fjfjjf'}
          position={{ lat: 48.88, lng: 2.36 }}
          name={'fjhjfj'}
          icon={{
            url: 'ICON' }}
        />


        <InfoWindow
          marker={this.state.activeMarker}
          visible={this.state.showingInfoWindow}
        >
          <div>
            <h1>{this.state.selectedPlace.name}</h1>
          </div>
        </InfoWindow>
      </Map>
    );
  }
}
export default GoogleApiWrapper({
  apiKey: 'AIzaSyDf0qX8Na9y5ehoHMyNnLObA45UUvMg-Ss'
})(GoogleMapsContainer);

const ICON = `M20.2,15.7L20.2,15.7c1.1-1.6,1.8-3.6,1.8-5.7c0-5.6-4.5-10-10-10S2,4.5,2,10c0,2,0.6,3.9,1.6,5.4c0,0.1,0.1,0.2,0.2,0.3
  c0,0,0.1,0.1,0.1,0.2c0.2,0.3,0.4,0.6,0.7,0.9c2.6,3.1,7.4,7.6,7.4,7.6s4.8-4.5,7.4-7.5c0.2-0.3,0.5-0.6,0.7-0.9
  C20.1,15.8,20.2,15.8,20.2,15.7z`;
