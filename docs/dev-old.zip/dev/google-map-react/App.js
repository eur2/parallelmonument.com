import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import ModalOpen from './components/ModalOpen';
import Modal from './components/Modal';

const Wrapper = styled.section`
  width: 100vw;
  height: 100vh;
`;

const App = ({ children }) => (
  <Wrapper>
    <header>
      <ModalOpen
        title={<h1>Parallel Monument</h1>}
        content={
          <div>
            <p>
              Parallel Monument is an architectural and urban research project
              empowering citizens to build virtual monuments for the
              representation of communal events. This website allows the
              proposition of monument projects and constitutes an archive of
              existing Parallel Monuments.
            </p>
            <p>
              Parallel Monument est project lauréat de Faire Paris, premier
              accélérateur de projets architecturaux et urbains innovants de la
              ville de Paris.
            </p>
          </div>
        }
      />
    </header>
    <nav className="index">
      <Modal
        title={<h1>Index</h1>}
        content={
          <div>
            <p>
              06/02/2011<br />Incendie du campement de Roms de 900 m² abritant
              une soixantaine de personnes. Un corps calciné est retrouvé sans
              pouvoir être identifié. L’enquête conclut que l’incendie est
              volontaire.
            </p>
            <p>
              27/10/2005<br />Bouna Traoré (15 ans) et Zyed Benna (17 ans)
              meurent par électrocution, alors qu’ils s’étaient réfugiés dans un
              local en béton abritant une réactance, pour fuir la police. Leur
              disparition a été à l’origine, de plusieurs semaines de
              protestations dans les banlieues.
            </p>
          </div>
        }
      />
    </nav>
    <nav className="apply">
      <Modal
        title={<h1>Apply</h1>}
        content={
          <div>
            <p>Submit</p>
          </div>
        }
      />
    </nav>
    {children}
  </Wrapper>
);

App.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.arrayOf(PropTypes.node)
  ])
};

App.defaultProps = {
  children: {}
};

export default App;
