import React, { Component, Fragment } from 'react';
import isEmpty from 'lodash.isempty';

// components:
import Marker from '../components/Marker';

// examples:
import GoogleMap from '../components/GoogleMap';

// consts
// import PARIS from '../const/la_center';

// Return map bounds based on list of places
const getMapBounds = (map, maps, places) => {
  const bounds = new maps.LatLngBounds();

  places.forEach(place => {
    bounds.extend(
      new maps.LatLng(place.geometry.location.lat, place.geometry.location.lng)
    );
  });
  return bounds;
};

// Re-center map when resizing the window
const bindResizeListener = (map, maps, bounds) => {
  maps.event.addDomListenerOnce(map, 'idle', () => {
    maps.event.addDomListener(window, 'resize', () => {
      map.fitBounds(bounds);
    });
  });
};

// Fit map to its bounds after the api is loaded
const apiIsLoaded = (map, maps, places) => {
  // Get bounds by our places
  const bounds = getMapBounds(map, maps, places);
  // Fit map to bounds
  map.fitBounds(bounds);
  // Bind the resize listener
  bindResizeListener(map, maps, bounds);
};

const exampleMapStyles = [
  {
    featureType: 'all',
    elementType: 'labels.text.fill',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'all',
    elementType: 'labels.text.stroke',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'all',
    elementType: 'geometry.fill',
    stylers: [{ visibility: 'on' }, { color: '#ffffff' }]
  },
  {
    featureType: 'all',
    elementType: 'geometry.stroke',
    stylers: [{ visibility: 'on' }, { color: '#000000' }]
  },
  {
    featureType: 'administrative',
    elementType: 'all',
    stylers: [{ visibility: 'on' }]
  },
  {
    featureType: 'administrative',
    elementType: 'labels.text.fill',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'administrative',
    elementType: 'labels.text.stroke',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'landscape',
    elementType: 'all',
    stylers: [{ visibility: 'on' }]
  },
  {
    featureType: 'poi',
    elementType: 'all',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road',
    elementType: 'all',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road',
    elementType: 'labels',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.fill',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road.arterial',
    elementType: 'all',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'road.local',
    elementType: 'geometry.stroke',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'transit',
    elementType: 'all',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'transit.station',
    elementType: 'all',
    stylers: [{ visibility: 'off' }]
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ visibility: 'off' }]
  }
];

class Main extends Component {
  constructor(props) {
    super(props);

    this.state = {
      places: []
    };
  }

  componentDidMount() {
    fetch('places.json')
      .then(response => response.json())
      .then(data => this.setState({ places: data.results }));
  }

  handleGoogleMapApi = google => {
    console.log(google);

    var blueCoords = [
      { lat: 48.865, lng: 2.345 },
      { lat: 48.865, lng: 2.355 },
      { lat: 48.875, lng: 2.345 },
      { lat: 48.885, lng: 2.355 }
    ];

    var redCoords = [
      { lat: 48.844, lng: 2.341 },
      { lat: 48.844, lng: 2.332 },
      { lat: 48.843, lng: 2.343 },
      { lat: 48.843, lng: 2.346 },
      { lat: 48.843, lng: 2.337 }
    ];

    var greenCoords = [
      { lat: 48.821, lng: 2.37 },
      { lat: 48.823, lng: 2.37 },
      { lat: 48.825, lng: 2.38 }
    ];

    // Construct a draggable red triangle with geodesic set to true.
    new google.maps.Polygon({
      map: google.map,
      paths: redCoords,
      strokeColor: '#000',
      strokeOpacity: 1,
      strokeWeight: 1,
      fillColor: '#FFFF00',
      fillOpacity: 0,
      draggable: true,
      editable: false,
      geodesic: true,
      title: 'title'
    });

    // Construct a draggable blue triangle with geodesic set to false.
    new google.maps.Polygon({
      map: google.map,
      paths: blueCoords,
      strokeColor: 'black',
      strokeOpacity: 0.8,
      strokeWeight: 1,
      fillColor: 'black',
      fillOpacity: 0,
      draggable: true,
      editable: false,
      geodesic: true,
                  title: 'title'
    });

    new google.maps.Polygon({
      map: google.map,
      paths: greenCoords,
      strokeColor: 'black',
      strokeOpacity: 1,
      strokeWeight: 2,
      fillColor: 'black',
      fillOpacity: 0,
      draggable: true,
      editable: true,
      geodesic: false,
                  title: 'title'

    });
    var lineSymbol = {
      path: 'M 0,-1 0,1',
      strokeOpacity: 1,
      scale: 4
    };
    var lineSymbol2 = {
    path: 'M -2,-2 2,2 M 2,-2 -2,2',
      strokeOpacity: 1,
      scale: 2
    };
      var symbolTwo = {
    path: 'M -1,0 A 1,1 0 0 0 -3,0 1,1 0 0 0 -1,0M 1,0 A 1,1 0 0 0 3,0 1,1 0 0 0 1,0M -3,3 Q 0,5 3,3',
    strokeColor: '#00F',
    rotation: 45
  };
    new google.maps.Polyline({
      path: [{ lat: 48.855, lng: 2.31 }, { lat: 48.856, lng: 2.32 }],
      strokeOpacity: 0,
      icons: [
        {
          icon: lineSymbol,
          offset: '0',
          repeat: '20px'
        }
      ],
                  title: 'title',
      map: google.map
    });
    new google.maps.Polyline({
      path: [{ lat: 48.9, lng: 2.34 }, { lat: 48.856, lng: 2.38 }],
      strokeOpacity: 0,
      icons: [
        {
          icon: lineSymbol,
          offset: '0',
          repeat: '20px'
        }
      ],
            title: 'title',
      map: google.map
    });
    new google.maps.Polyline({
      path: [{ lat: 48.885, lng: 2.35 }, { lat: 48.895, lng: 2.37 }],
      strokeOpacity: 0,
      icons: [
        {
          icon: lineSymbol2,
          offset: '0',
          repeat: '20px'
        }
      ],
      title: 'title',
      map: google.map
    });
    /*var goldStar = {
      path:
        'M 125,5 155,90 245,90 175,145 200,230 125,180 50,230 75,145 5,90 95,90 z',
      fillColor: 'yellow',
      fillOpacity: 0,
      scale: 0.2,
      strokeColor: 'black',
      strokeWeight: 3
    };

    new google.maps.Marker({
      position: google.map.getCenter(),
      icon: goldStar,
      map: google.map
    });*/

    var contentString = '<div id="content">'+
      '<div id="siteNotice">'+
      '</div>'+
      '<h1 id="firstHeading" class="firstHeading">Uluru</h1>'+
      '<div id="bodyContent">'+
      '<p><b>Uluru</b>, also referred to as <b>Ayers Rock</b>, is a large ' +
      'sandstone rock formation in the southern part of the '+
      'Northern Territory, central Australia. It lies 335&#160;km (208&#160;mi) '+
      'south west of the nearest large town, Alice Springs; 450&#160;km '+
      '(280&#160;mi) by road. Kata Tjuta and Uluru are the two major '+
      'features of the Uluru - Kata Tjuta National Park. Uluru is '+
      'sacred to the Pitjantjatjara and Yankunytjatjara, the '+
      'Aboriginal people of the area. It has many springs, waterholes, '+
      'rock caves and ancient paintings. Uluru is listed as a World '+
      'Heritage Site.</p>'+
      '<p>Attribution: Uluru, <a href="https://en.wikipedia.org/w/index.php?title=Uluru&oldid=297882194">'+
      'https://en.wikipedia.org/w/index.php?title=Uluru</a> '+
      '(last visited June 22, 2009).</p>'+
      '</div>'+
      '</div>';

  var infowindow = new google.maps.InfoWindow({
    content: contentString
  });

  
  Marker.addListener('click', function() {
    infowindow.open(google.map, Marker);
  });
  };

  render() {
    const { places } = this.state;
    return (
      <Fragment>
        {!isEmpty(places) && (
          <GoogleMap
            defaultZoom={12}
            defaultCenter={[48.85, 2.31]}
            options={{ styles: exampleMapStyles }}
            yesIWantToUseGoogleMapApiInternals
            onGoogleApiLoaded={({ map, maps }) =>
            apiIsLoaded(map, maps, places)
          }            >
            {places.map(place => (
              <Marker
                key={place.id}
                text={place.name}
                lat={place.geometry.location.lat}
                lng={place.geometry.location.lng}

              >   </Marker>
            ))}
          </GoogleMap>
        )}
      </Fragment>
    );
  }
}

export default Main;
