export default [48.858, 2.2069];
