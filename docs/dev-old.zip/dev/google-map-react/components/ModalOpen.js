import React from 'react';

export default class Modal extends React.Component {
	state = {
		open: true
	};

	handleClick = () => {
		this.setState(prevState => ({
			open: !prevState.open
		}));
	};

	render() {
		const { title, content } = this.props;
		const { open } = this.state;

		return (
			<div>
				<button onClick={this.handleClick}>
					{open ? title : title}
				</button>
				{open ? (
					<div className="open" onClick={this.handleClick}>
						{content}
					</div>
				) : null}
			</div>
		);
	}
}
