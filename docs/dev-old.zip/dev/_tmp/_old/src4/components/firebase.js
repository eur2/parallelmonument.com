//import * as firebase from 'firebase';
import Firebase from '../.env';

const auth = Firebase.auth();

export {
  auth
}