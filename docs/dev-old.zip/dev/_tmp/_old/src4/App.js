import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Home from './Home';
import Admin from './Admin';
/*import AppProvider, {
  Consumer
} from './components/AppProvider';
import Login from './components/Login';*/

const App = () => (

  <Router>
    <>
      <Route exact path={'/'} component={Home} />
      <Route exact path={'/admin'} component={Admin} />

    </>
  </Router>

);

export default App;
