const config = {
  firebase: {
    apiKey: "AIzaSyCuwgletl8Att0D1eG9-PORGSq-fuaOGG4",
    authDomain: "pm-dev-bc463.firebaseapp.com",
    databaseURL: "https://pm-dev-bc463.firebaseio.com",
    projectId: "pm-dev-bc463",
    storageBucket: "pm-dev-bc463.appspot.com",
    messagingSenderId: "767157584119"
  }
};

export default config;
