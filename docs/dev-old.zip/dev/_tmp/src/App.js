import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Home from './Home';
import Auth from './Admin';
//import Auth from './Auth';

const App = () => (
  <Router>
    <>
      <Route exact path={'/'} component={Home} />
      <Route exact path={'/admin'} component={Auth} />
    </>
  </Router>
);
export default App;