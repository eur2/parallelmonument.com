import firebase from "firebase/app"
// import "firebase/database"
// import "firebase/auth"

//import { useState, useEffect } from "react"

const config = {
    apiKey: "AIzaSyCtYbpFnlBAxeqBy9xdcZc4H6S8_AYtj6Q",
    authDomain: "parallel-monument.firebaseapp.com",
    databaseURL: "https://parallel-monument.firebaseio.com",
    projectId: "parallel-monument",
    storageBucket: "parallel-monument.appspot.com",
    messagingSenderId: "915319114232"
}

// firebase.initializeApp(config)

// const app = firebase.initializeApp(config)
// const db = app.database()

// export { app }
// export { db }

export default (!firebase.apps.length ? firebase.initializeApp(config) : firebase.app())
