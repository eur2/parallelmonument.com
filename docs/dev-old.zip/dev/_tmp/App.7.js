import React from 'react';
import Firebase from 'firebase/app';
import 'firebase/database';
import config from './.config';
//import Modal from './components/modal';
//import { GoogleApiWrapper, InfoWindow, Map, Marker } from 'google-maps-react';
//import icon from './components/marker.svg';

class App extends React.Component {
  constructor(props) {
    super(props);
    Firebase.initializeApp(config.firebase);

    this.state = {
      developers: [],
      mapClick: false,
      mapClickLat: '',
      mapClickLng: '',
      modalOpen: false,
      showingInfoWindow: false,
      activeMarker: {},
      selectedPlace: {},
      lang: 'fr',
      mapType: 'satellite',
      onEditClick: true
    };
  }

  componentDidMount() {
    this.getUserData();
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState !== this.state.developers) {
      this.writeUserData();
    }
  }

  writeUserData = () => {
    Firebase.database()
      .ref('/developers')
      .set(this.state.developers);
    //console.log("DATA SAVED");
  };

  getUserData = () => {
    let ref = Firebase.database().ref('/');
    ref.on('value', snapshot => {
      const state = snapshot.val();
      this.setState(state);
      //console.log(state);
    });
  };

  handleClose = () => {
    this.setState({
      modalOpen: false,
      mapClick: false
    });
  };
  onChange = coord => {
    const { latLng } = coord;
    this.setState({
      mapClickLat: latLng.lat(),
      mapClickLng: latLng.lng()
    });
  };

  onMarkerClick = (props, marker, e) => {
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });
  };

  onMapClick = (props, marker, coord) => {
    const { latLng } = coord;
    this.setState({
      mapClick: true,
      mapClickLat: latLng.lat(),
      mapClickLng: latLng.lng(),
      modalOpen: true
    });
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };
  onMapTypeSat = () => {
    this.setState({
      mapType: 'satellite'
    });
  };
  onMapTypeTerrain = () => {
    this.setState({
      mapType: 'terrain'
    });
  };
  onLangFr = () => {
    this.setState({
      lang: 'fr'
    });
  };
  onLangEn = () => {
    this.setState({
      lang: 'en'
    });
  };
  handleSubmit = event => {
    event.preventDefault();
    let lat = parseFloat(this.refs.lat.value);
    let lng = parseFloat(this.refs.lng.value);
    let name = this.refs.name.value;
    let title = this.refs.title.value;
    let role = this.refs.role.value;
    let uid = this.refs.uid.value;

    if (uid && name && title && role && lat && lng) {
      const { developers } = this.state;
      const devIndex = developers.findIndex(data => {
        return data.uid === uid;
      });
      developers[devIndex].lat = lat;
      developers[devIndex].lng = lng;
      developers[devIndex].name = name;
      developers[devIndex].title = title;
      developers[devIndex].role = role;
      this.setState({ developers });
    } else if (lat && lng && name && title && role) {
      const uid = new Date().getTime().toString();
      const { developers } = this.state;
      developers.push({ lat, lng, uid, name, title, role });
      this.setState({ developers });
    }

    this.refs.lat.value = '';
    this.refs.lng.value = '';
    this.refs.name.value = '';
    this.refs.title.value = '';
    this.refs.role.value = '';
    this.refs.uid.value = '';
    this.setState({
      modalOpen: false
    });
  };

  removeData = developer => {
    const { developers } = this.state;
    const newState = developers.filter(data => {
      return data.uid !== developer.uid;
    });
    this.setState({ developers: newState });
  };

  updateData = developer => {
    this.refs.uid.value = developer.uid;
    this.refs.name.value = developer.name;
    this.refs.role.value = developer.role;
    this.refs.lat.value = developer.lat;
    this.refs.lng.value = developer.lng;
    this.refs.title.value = developer.title;
  };
  onCloseForm = event => {
    event.stopPropagation();
  };

  render() {
    const { developers } = this.state;

    return (
      <React.Fragment>
        <div className="row">
          <h1>Parallel Monument</h1>
        </div>
        <div className="row">
          {developers.map(developer => (
            <div key={developer.uid}>
              <div className="card-body">
                <p className="card-text-latlng">
                  <span className="bborder">{developer.lat}</span>
                  <span className="bborder">{developer.lng}</span>
                </p>
                <p>{developer.name}</p>
                <p className="card-text" style={{ textAlign: 'center' }}>
                  {developer.title}
                </p>
                <p className="card-text">{developer.role}</p>
                <button
                  onClick={() => this.removeData(developer)}
                  className="btn btn-link"
                >
                  Delete
                </button>
                <button
                  onClick={() => this.updateData(developer)}
                  className="btn btn-link"
                >
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>

       <form
          onSubmit={this.handleSubmit}
          className="border admin"
          //style={{ display: onEditClick ? 'flex' : 'none' }}
        >
          <div style={{ textAlign: 'center' }}>
            <button onClick={this.onCloseForm}>×</button>
          </div>
          <div className="form-row">
            <div>
              <label>Latitude</label>
              <input
                type="text"
                ref="lat"
                placeholder="0"
              />
            </div>
            <div>
              <label>Longitude</label>
              <input
                type="text"
                ref="lng"
                placeholder="0"
              />
            </div>
          </div>
          <div className="form-row">
            <input type="hidden" ref="uid" />
            <div>
              <label>Qui</label>
              <input type="text" ref="name" placeholder="Votre nom" />
            </div>
            <div>
              <label>Quand</label>
              <input type="text" ref="title" placeholder="JJ/MM/AAAA" />
            </div>
            <div>
              <label>Quoi</label>
              <textarea type="text" ref="role" placeholder="Votre texte" />
            </div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <button type="submit">Enregistrer</button>
          </div>
       </form>
      </React.Fragment>
    );
  }
}

export default App;
