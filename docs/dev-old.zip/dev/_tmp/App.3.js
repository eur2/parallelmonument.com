import React from 'react';
import Firebase from 'firebase/app';
import 'firebase/database';
import config from './.config';
import Modal from './components/modal';
import { GoogleApiWrapper, InfoWindow, Map, Marker } from 'google-maps-react';
import icon from './components/marker.svg';
  

class App extends React.Component {
  constructor(props) {
    super(props);
    Firebase.initializeApp(config.firebase);

    this.state = {
      developers: [],
      mapClick: false,
      mapClickLat: '',
      mapClickLng: '',
      modalOpen: false,
      showingInfoWindow: false,
      activeMarker: {},
      selectedPlace: {},
      lang: 'fr',
      mapType:'satellite'
    };
  }

  componentDidMount() {
    this.getUserData();
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState !== this.state.developers) {
      this.writeUserData();
    }

  }

  writeUserData = () => {
    Firebase.database()
      .ref('/developers')
      .set(this.state.developers);
    //console.log("DATA SAVED");
  };

  getUserData = () => {
    let ref = Firebase.database().ref('/');
    ref.on('value', snapshot => {
      const state = snapshot.val();
      this.setState(state);
      //console.log(state);
    });
  };

  handleClose = () => {
    this.setState({
      modalOpen: false,
      mapClick: false
    });
  };
  onChange = coord => {
    const { latLng } = coord;
    this.setState({
      mapClickLat: latLng.lat(),
      mapClickLng: latLng.lng()
    });
  };

  onMarkerClick = (props, marker, e) => {
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });
  };

  onMapClick = (props, marker, coord) => {
    const { latLng } = coord;
    this.setState({
      mapClick: true,
      mapClickLat: latLng.lat(),
      mapClickLng: latLng.lng(),
      modalOpen: true
    });
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };
  onMapTypeSat = () => {
    this.setState({
      mapType: 'satellite'
    });
  };
  onMapTypeTerrain = () => {
    this.setState({
      mapType: 'terrain'
    });
  };
  onLangFr = () => {
    this.setState({
      lang: 'fr'
    });
  };
  onLangEn = () => {
    this.setState({
      lang: 'en'
    });
  };
  /*onClick(t, map, coord) {
    const { latLng } = coord;
    const lat = latLng.lat();
    const lng = latLng.lng();
    console.log(lat);
    console.log(lng);
  }/*
  /*keyPressed(event) {
    if (event.key === "Enter") {
      this.handleSubmit();
    }
  }*/
  handleSubmit = event => {
    event.preventDefault();
    let lat = parseFloat(this.refs.lat.value);
    let lng = parseFloat(this.refs.lng.value);
    let name = this.refs.name.value;
    let title = this.refs.title.value;
    let role = this.refs.role.value;
    let uid = this.refs.uid.value;

    if (uid && name && title && role && lat && lng) {
      const { developers } = this.state;
      const devIndex = developers.findIndex(data => {
        return data.uid === uid;
      });
      developers[devIndex].lat = lat;
      developers[devIndex].lng = lng;
      developers[devIndex].name = name;
      developers[devIndex].title = title;
      developers[devIndex].role = role;
      this.setState({ developers });
    } else if (lat && lng && name && title && role) {
      const uid = new Date().getTime().toString();
      const { developers } = this.state;
      developers.push({ lat, lng, uid, name, title, role });
      this.setState({ developers });
    }

    this.refs.lat.value = '';
    this.refs.lng.value = '';
    this.refs.name.value = '';
    this.refs.title.value = '';
    this.refs.role.value = '';
    this.refs.uid.value = '';
    this.setState({
      modalOpen: false
    });
  };

  /*updateData = developer => {
    this.refs.lat.value = developer.lat;
    this.refs.lng.value = developer.lng;
    this.refs.uid.value = developer.uid;
    this.refs.name.value = developer.name;
    this.refs.role.value = developer.role;
  };*/

  static defaultProps = {
    center: {
      lat: 48.8989,
      lng: 2.3444
    },
    zoom: 18
  };

  render() {
    const {
      developers,
      modalOpen,
      mapClick,
      mapClickLat,
      mapClickLng,
      lang,
      mapType
    } = this.state;

    return (
      <React.Fragment>
        <header>
          <Modal
            title={<h1 className="button">Parallel Monument</h1>}
            content={
              lang === 'fr' ? (
                <div className="content">
                  <h3>
                    Parallel Monument est un projet de cartographie
                    communautaire qui géolocalise histoires individuelles et
                    collectives dans l’espace de la ville.
                  </h3>
                  <br />
                  <h3>
                    Les participants au projet pourront placer des signes de
                    mémoires communautaires sur le calque virtuel de la ville.
                    Ces signes, circonscrits ou non, véhicules symboliques des
                    histoires sélectionnées par la communauté, seront
                    consultables en ligne.
                  </h3>{' '}
                  <br />
                  <h3>
                    Parralel Monument est un projet lauréat du programme FAIRE,
                    lancé par le Pavillon de l’Arsenal et développé par MBL
                    architectes : Sebastien Martinez-Barat, Benjamin Lafore,
                    Robin Durand, Véranie Jeune avec Max Thurnheim et
                    Eurogroupe.
                  </h3>
                </div>
              ) : (
                <div className="content">
                  <h3>
                    Parallel Monument is a community mapping project that
                    geolocates individual and collective stories in the space of
                    the city.
                  </h3>
                  <br />
                  <h3>
                    Participants will be able to place communal memory signs on
                    the virtual layer of the city.
                  </h3>
                  <br />
                  <h3>
                    These signs, symbolizing the stories selected by the
                    community, will be available online. Parallel Monument is a
                    winning project of the FAIRE program, launched by Pavillon
                    de l’Arsenal and developed by MBL architects: Sébastien
                    Martinez-Barat, Benjamin Lafore, Robin Durand, Véranie
                    Jeune, in collaboration with Max Turnheim and Eurogroup.
                  </h3>
                </div>
              )
            }
          />
        </header>
        <nav>
          <Modal
            title={<h2 className="button">+</h2>}
            content={
              lang === 'fr' ? (
                <div className="content">
                  <h3>Créer un Parralel Monument</h3>
                  <br />
                  <h3>1. Ils existent sous forme d’information.</h3>
                  <h3>
                    2. Ils sont des représentations dont la fonction est
                    symbolique.
                  </h3>
                  <h3>
                    3. Ils commémorent un évènement et son inscription dans
                    l’espace{' '}
                  </h3>
                  <h3>4. Ils prennent la forme d’une limite. </h3>
                  <h3>
                    5. Ils peuvent se superposer et ainsi produire des
                    intersections.
                  </h3>
                  <br />
                  <p>
                    De cette liste de caractéristiques découle un ensemble de
                    questions. Qu'implique le fait de revendiquer un territoire
                    sans être obligé de le réclamer à quelqu'un ? La violence
                    inhérente à l'appropriation est-elle nécessaire pour
                    affirmer la validité d'un monument ? L'espace commun de la
                    cartographie permet-il une transformation normative
                    suffisante pour valoir la peine d'être investie ? Le projet
                    Parallel Monuments explore toutes ces questions à travers
                    des outils cartographiques. L'étude prend la forme est d'une
                    série de Parallel Monuments (enceintes positionnées à
                    l'échelle mondiale et se chevauchant) et d'une plateforme
                    accessible au public pour accroître et modifier la
                    géographie de la commémoration à l'échelle mondiale.
                  </p>
                </div>
              ) : (
                <div className="content">
                  <h2>Create a Parallel Monument</h2>
                  <br />
                  <h3>1. They exist in the information space.</h3>
                  <h3>
                    2. They are a representation and function on the symbolic
                    level.
                  </h3>
                  <h3>3. They commemorate an event and its spatiality.</h3>
                  <h3>4. Their form is one of boundary.</h3>
                  <h3>
                    5. They can overlap with each other, producing so-called
                    intersections.
                  </h3>
                  <br />
                  <p>
                    From this declarative list of feature, a set of questions
                    arise: what does it imply to claim a territory while not
                    being forced to claim it from someone? Is the inherent
                    violence of appropriation necessary to assert the validity
                    of a monument? Does the shared space of cartography allow
                    for enough normative transformation to be worth
                    investigating? The project Parallel Monuments attempts to
                    explore these questions through a map, cartographic tools
                    and thorough documentation. The result of this investigation
                    is a number of Parallel Monuments (globally positioned and
                    overlapping enclosures) and a publicly accessible input
                    method for growing and modifying the geography of
                    commemoration on a wolrdwide level.
                  </p>
                </div>
              )
            }
          />
        </nav>
        <div className="lang">
        <button
            onClick={this.onMapTypeSat}
            className={mapType === 'satellite' ? 'current' : null}
          >
            Satellite
          </button>
          <button
            onClick={this.onMapTypeTerrain}
            className={mapType === 'terrain' ? 'current' : null}
          >
            {lang === 'fr' ? 'Plan' : 'Map'}
          </button>
          <button
            onClick={this.onLangFr}
            className={lang === 'fr' ? 'current' : null}
          >
            FR
          </button>
          <button
            onClick={this.onLangEn}
            className={lang === 'en' ? 'current' : null}
          >
            EN
          </button>
        </div>

        {modalOpen ? (
          <form onSubmit={this.handleSubmit} className="border">
            <div className="latlng">
              <div className="border">
                <input
                  type="text"
                  ref="lat"
                  value={mapClickLat}
                  onChange={this.onChange}
                />
              </div>
              <div className="border">
                <input
                  type="text"
                  ref="lng"
                  value={mapClickLng}
                  onChange={this.onChange}
                />
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <button onClick={this.handleClose}>×</button>
            </div>
            <div className="form-row">
              <input type="hidden" ref="uid" />
              <div>
                <label>{lang === 'fr' ? 'Qui' : 'Who'}</label>
                <input
                  type="text"
                  ref="name"
                  placeholder={lang === 'fr' ? 'Votre nom' : 'Your name'}
                  pattern=".+"

                />
              </div>
              <div>
                <label>{lang === 'fr' ? 'Quand' : 'When'}</label>
                <input
                  type="text"
                  ref="title"
                  placeholder={lang === 'fr' ? 'JJ/MM/AAAA' : 'DD/MM/YYYY'}
                  pattern="[0-9]{2}/[0-9]{2}/[0-9]{4}"
                />
              </div>
              <div>
                <label>{lang === 'fr' ? 'Quoi' : 'What'}</label>
                <textarea
                  type="text"
                  ref="role"
                  placeholder={lang === 'fr' ? 'Votre texte' : 'Your text'}
                  pattern=".+"
                />
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <button type="submit">
                {lang === 'fr' ? 'Enregistrer' : 'Save'}
              </button>
            </div>
          </form>
        ) : null}

        <Map
        key={mapType}
          style={{ height: '100%', width: '100%', cursor: 'pointer' }}
          google={this.props.google}
          onClick={this.onMapClick}
          zoom={this.props.zoom}
          initialCenter={this.props.center}
          styles={[
            {
              featureType: 'all',
              stylers: [{ saturation: -100 }]
            }
          ]}
          mapTypeControl={false}
          fullscreenControl={false}
          streetViewControl={false}
          panControl={false}
          rotateControl={false}
          mapType={mapType}
          
        >
          {mapClick ? (
            <Marker position={{ lat: mapClickLat, lng: mapClickLng }}               icon={icon}
            />
          ) : null}
          {developers.map(developer => (
            <Marker
              onClick={this.onMarkerClick}
              key={developer.uid}
              position={{ lat: developer.lat, lng: developer.lng }}
              title={developer.title}
              txt={developer.role}
              name={developer.name}
              icon={icon}
            />
          ))}
          <InfoWindow
            marker={this.state.activeMarker}
            visible={this.state.showingInfoWindow}
          >
            <div className="infowindow">
              <p>{this.state.selectedPlace.name}</p>
              <p style={{ textAlign: 'center' }}>
                {this.state.selectedPlace.title}
              </p>
              <p>{this.state.selectedPlace.txt}</p>
            </div>
          </InfoWindow>
        </Map>
      </React.Fragment>
    );
  }
}
export default GoogleApiWrapper({
  apiKey: 'AIzaSyDf0qX8Na9y5ehoHMyNnLObA45UUvMg-Ss'
})(App);
/*class App extends React.Component {
  constructor(props) {
    super(props);
    Firebase.initializeApp(config.firebase);

    this.state = {
      developers: []
    };
  }

  componentDidMount() {
    this.getUserData();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState !== this.state) {
      this.writeUserData();
    }
  }

  writeUserData = () => {
    Firebase.database()
      .ref("/")
      .set(this.state);
    console.log("DATA SAVED");
  };

  getUserData = () => {
    let ref = Firebase.database().ref("/");
    ref.on("value", snapshot => {
      const state = snapshot.val();
      this.setState(state);
    });
  };

  handleSubmit = event => {
    event.preventDefault();
    let name = this.refs.name.value;
    let role = this.refs.role.value;
    let uid = this.refs.uid.value;

    if (uid && name && role) {
      const { developers } = this.state;
      const devIndex = developers.findIndex(data => {
        return data.uid === uid;
      });
      developers[devIndex].name = name;
      developers[devIndex].role = role;
      this.setState({ developers });
    } else if (name && role) {
      const uid = new Date().getTime().toString();
      const { developers } = this.state;
      developers.push({ uid, name, role });
      this.setState({ developers });
    }

    this.refs.name.value = "";
    this.refs.role.value = "";
    this.refs.uid.value = "";
  };

  removeData = developer => {
    const { developers } = this.state;
    const newState = developers.filter(data => {
      return data.uid !== developer.uid;
    });
    this.setState({ developers: newState });
  };

  updateData = developer => {
    this.refs.uid.value = developer.uid;
    this.refs.name.value = developer.name;
    this.refs.role.value = developer.role;
  };

  render() {
    const { developers } = this.state;

    return (
      <React.Fragment>
        <SimpleMap />
        <div className="container">
          <div className="row">
            <div className="col-xl-12">
              <h1>Firebase Development Team</h1>
            </div>
          </div>
          <div className="row">
            <div className="col-xl-12">
              {developers.map(developer => (
                <div
                  key={developer.uid}
                  className="card float-left"
                  style={{ width: "18rem", marginRight: "1rem" }}
                >
                  <div className="card-body">
                    <h5 className="card-title">{developer.name}</h5>
                    <p className="card-text">{developer.role}</p>
                    <button
                      onClick={() => this.removeData(developer)}
                      className="btn btn-link"
                    >
                      Delete
                    </button>
                    <button
                      onClick={() => this.updateData(developer)}
                      className="btn btn-link"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="row">
            <div className="col-xl-12">
              <h1>Add new team member here</h1>
              <form onSubmit={this.handleSubmit}>
                <div className="form-row">
                  <input type="hidden" ref="uid" />
                  <div className="form-group col-md-6">
                    <label>Name</label>
                    <input
                      type="text"
                      ref="name"
                      className="form-control"
                      placeholder="Name"
                    />
                  </div>
                  <div className="form-group col-md-6">
                    <label>Role</label>
                    <input
                      type="text"
                      ref="role"
                      className="form-control"
                      placeholder="Role"
                    />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary">
                  Save
                </button>
              </form>
            </div>
          </div>
          <div className="row">
            <div className="col-xl-12">
              <h3>
                Tutorial{" "}
                <a href="https://sebhastian.com/react-firebase-real-time-database-guide">
                  here
                </a>
              </h3>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default App;*/
